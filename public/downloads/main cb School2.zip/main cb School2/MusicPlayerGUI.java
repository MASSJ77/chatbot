import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
public class MusicPlayerGUI {
    private MusicPlayer musicPlayer;
    private JFrame musicPlayerFrame;
    private JTextArea displayArea;
    private JLabel currentSongLabel;

    public MusicPlayerGUI(MusicPlayer musicPlayer) {
        this.musicPlayer = musicPlayer;
    }

    public void showMusicPlayer() {
        // Create the main frame
        musicPlayerFrame = new JFrame("Music Player");
        musicPlayerFrame.setSize(500, 600);
        musicPlayerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        musicPlayerFrame.setLayout(new BorderLayout());
        musicPlayerFrame.getContentPane().setBackground(new Color(245, 250, 255));

        // Top Panel: Current Song Display
        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(30, 144, 255));
        topPanel.setLayout(new BorderLayout());
        currentSongLabel = new JLabel("No song playing", SwingConstants.CENTER);
        currentSongLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        currentSongLabel.setForeground(Color.WHITE);
        topPanel.add(currentSongLabel, BorderLayout.CENTER);
        musicPlayerFrame.add(topPanel, BorderLayout.NORTH);

        // Center: Display Area for Song Library
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        displayArea.setMargin(new Insets(10, 10, 10, 10));
        displayArea.setBorder(BorderFactory.createLineBorder(new Color(220, 230, 240), 2));
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        musicPlayerFrame.add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel: Control Buttons
        JPanel controlPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        controlPanel.setBackground(new Color(220, 230, 240));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton showLibraryButton = createStyledButton("Show Library");
        JButton selectSongButton = createStyledButton("Select Song");
        JButton playButton = createStyledButton("Play");
        JButton pauseButton = createStyledButton("Pause");
        JButton skipButton = createStyledButton("Skip");
        JButton stopButton = createStyledButton("Stop");
        JButton ATQ = createStyledButton("+=");
        JButton YM = createStyledButton("YouTube Music");
        
        controlPanel.add(showLibraryButton);
        controlPanel.add(selectSongButton);
        controlPanel.add(playButton);
        controlPanel.add(pauseButton);
        controlPanel.add(skipButton);
        controlPanel.add(stopButton);
        controlPanel.add(ATQ);
        controlPanel.add(YM);


        musicPlayerFrame.add(controlPanel, BorderLayout.SOUTH);

        // Button Listeners
        showLibraryButton.addActionListener(e -> displayArea.setText(musicPlayer.displayLibrary()));

        selectSongButton.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(musicPlayerFrame, "Enter song number to select:");
            if (input != null) {
                try {
                    int songIndex = Integer.parseInt(input);
                    String message = musicPlayer.selectSong(songIndex);
                    currentSongLabel.setText("Now Playing: " + message.split(":")[1]);
                    displayArea.append("\n" + message + "\n");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(musicPlayerFrame, "Invalid input. Please enter a number.");
                }
            }
        });

        playButton.addActionListener(e -> updateCurrentSong(musicPlayer.playNext()));
        pauseButton.addActionListener(e -> displayArea.append("\n" + musicPlayer.pause() + "\n"));
        skipButton.addActionListener(e -> updateCurrentSong(musicPlayer.skip()));
        YM.addActionListener(e -> openYouTubeMusic());
        
        stopButton.addActionListener(e -> {
            displayArea.append("\n" + musicPlayer.stop() + "\n");
            currentSongLabel.setText("No song playing");
        });

        
        
        ATQ.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(musicPlayerFrame, "Enter song name to add to queue:");
            if (input != null && !input.trim().isEmpty()) {
                String message = musicPlayer.addToQueue(input.trim());
                displayArea.append("\n" + message + "\n");
                JOptionPane.showMessageDialog(musicPlayerFrame, "Added to queue: " + input);
            } else {
                JOptionPane.showMessageDialog(musicPlayerFrame, "Invalid input. Please enter a song name.");
            }
        });
        
        // Add animations and effects
        addHoverEffects(showLibraryButton);
        addHoverEffects(selectSongButton);
        addHoverEffects(playButton);
        addHoverEffects(pauseButton);
        addHoverEffects(skipButton);
        addHoverEffects(stopButton);
        addHoverEffects(ATQ);
        
        // Display the music player
        musicPlayerFrame.setVisible(true);
    }

    private void openYouTubeMusic() {
    try {
        Desktop desktop = Desktop.getDesktop();
        if (Desktop.isDesktopSupported() && desktop.isSupported(Desktop.Action.BROWSE)) {
            desktop.browse(new URL("https://music.youtube.com").toURI());
        } else {
            JOptionPane.showMessageDialog(musicPlayerFrame, "Unable to open browser. Desktop feature not supported.");
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(musicPlayerFrame, "Error opening YouTube Music: " + ex.getMessage());
    }
}
    // Helper Method: Update Current Song Label
    private void updateCurrentSong(String message) {
        if (message.startsWith("Now playing:")) {
            currentSongLabel.setText(message.split(":")[1]);
        }
        displayArea.append("\n" + message + "\n");
    }

    // Helper Method: Create Styled Buttons
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(new Color(30, 215, 96));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    // Helper Method: Add Hover Effects to Buttons
    private void addHoverEffects(JButton button) {
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(25, 190, 85)); // Darker shade on hover
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(30, 215, 96)); // Original color
            }
        });
    }
}
